package poo;

public class Aviao extends Carro {
    double envergadura;
    
    void aterrisar() {
    	System.out.println("---------______________");
    	
    }
    
    void acelerar() {
    	System.out.println("_________----------");
    }
}